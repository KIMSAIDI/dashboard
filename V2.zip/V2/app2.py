import requests
import pandas as pd
import dash
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output, State
import plotly.express as px
import warnings

# Ignore warnings related to urllib3
warnings.filterwarnings("ignore", message=".*NotOpenSSLWarning.*")

# Function to fetch data from LRS
def fetch_lrs_data():
    endpoint = "https://lrsels.lip6.fr/data/xAPI/statements"
    headers = {
        "X-Experience-API-Version": "1.0.3"
    }
    auth = ("9fe9fa9a494f2b34b3cf355dcf20219d7be35b14", "b547a66817be9c2dbad2a5f583e704397c9db809")

    params = {
        "agent": '{"account": {"homePage": "https://www.lip6.fr/mocah/", "name": "C2ED0A43"}}',
        "limit": 500
    }

    response = requests.get(endpoint, headers=headers, auth=auth, params=params)

    if response.status_code == 200:
        data = response.json()["statements"]
        return data
    else:
        raise Exception(f"Error fetching data: {response.status_code}, {response.text}")

# Extract the actor name
def get_actor_name(data):
    for statement in data:
        actor_name = statement["actor"].get("name")
        if actor_name:
            return actor_name
    return "Inconnu"

# Process the data and extract relevant fields
def process_data(data):
    records = []
    last_mission_level = None
    all_mission_levels = set()
    completed_counts = {}
    score_by_level = {}

    for statement in data:
        try:
            success = statement.get("result", {}).get("success", False)
            score = statement.get("result", {}).get("extensions", {}).get("https://spy.lip6.fr/xapi/extensions/score", None)

            if not success:
                score = None

            if score:
                if isinstance(score, list) and len(score) > 0:
                    score = score[0]

                if isinstance(score, str):
                    score = float(score)

                if isinstance(score, (int, float)):
                    score = float(score)
                else:
                    score = None
            else:
                score = None

            mission_level = None
            scenario = None  # New variable for scenario
            if "object" in statement:
                object_data = statement["object"]
                if "definition" in object_data:
                    definition = object_data["definition"]
                    if "extensions" in definition:
                        extensions = definition["extensions"]
                        if "https://w3id.org/xapi/seriousgames/extensions/progress" in extensions:
                            mission_level = extensions["https://w3id.org/xapi/seriousgames/extensions/progress"][0]
                        if "https://spy.lip6.fr/xapi/extensions/context" in extensions:
                            scenario = extensions["https://spy.lip6.fr/xapi/extensions/context"][0]

            if mission_level is None and last_mission_level is not None:
                mission_level = last_mission_level

            if mission_level is not None:
                last_mission_level = mission_level
                all_mission_levels.add(mission_level)

                # Count completed actions by mission level
                verb = statement["verb"]["id"].split("/")[-1]
                if verb == "completed":
                    if mission_level not in completed_counts:
                        completed_counts[mission_level] = 0
                    completed_counts[mission_level] += 1

                # Calculate scores for average score calculation
                if mission_level not in score_by_level:
                    score_by_level[mission_level] = []
                if score is not None:
                    score_by_level[mission_level].append(score)

            records.append({
                "Timestamp": statement.get("timestamp"),
                "Verb": statement["verb"]["id"].split("/")[-1],
                "Actor": statement["actor"].get("name", "Unknown"),
                "Object": statement["object"].get("id", "Unknown"),
                "Score": score,
                "Mission Level": mission_level,
                "Scenario": scenario  # Add the scenario to the record
            })
        except Exception as e:
            continue

        # Calculate the average score for each mission level, safely handle division by zero
        avg_score_by_level = {
            level: round(sum(scores) / len(scores)) if len(scores) > 0 else None
            for level, scores in score_by_level.items()
        }

    return pd.DataFrame(records), list(all_mission_levels), completed_counts, avg_score_by_level


# Initial data
data = fetch_lrs_data()
actor_name = get_actor_name(data)  # Extract actor name
df, mission_levels, completed_counts, avg_score_by_level = process_data(data)

# Create Dash app
app = dash.Dash(__name__)

app.layout = html.Div([
    html.Div([
        html.Button(f"Joueur n°{actor_name}", id="toggle-id-button", n_clicks=0, className="toggle-id-button"),
        html.Button("Basculer la vue", id="toggle-view-button", n_clicks=0, className="toggle-view-button"),
    ], className='header-container'),

    html.Div([

        html.H1("Suivre ma progression", className='dashboard-title'),
        # Single container for both views
        html.Div(id='view-container', children=[
            # General View
            html.Div([
                # General view contents (graphs and tables)
                html.Div([
                    html.Label("Évolution des scores par niveau de mission :"),
                    html.Div([
                        dcc.Graph(id='score-evolution'),
                    ], className="dash-graph-box"),  # Graph in a box

                ], className="dash-graph-container"),

                html.Div([
                    html.Label("Score moyen par niveau de mission :"),
                    html.Div([
                        dash_table.DataTable(
                            id='avg-score-table',
                            columns=[
                                {"name": "Mission Level", "id": "Mission Level"},
                                {"name": "Score Moyen", "id": "Average Score"}
                            ],
                            data=[{"Mission Level": level, "Average Score": avg_score} for level, avg_score in avg_score_by_level.items()],
                            style_table={'height': '300px', 'overflowY': 'auto'},
                            style_cell={'textAlign': 'center', 'padding': '10px'},
                        )
                    ], className="dash-table-box"),  # Table in a box
                ], className="dash-table-container"),
            ], id="general-view", style={'display': 'block'}),  # Initially show general view

            # Mission View
            html.Div([
                # Filters section
                html.Div([
                    html.Label("Afficher uniquement les lignes avec score:"),
                    dcc.Checklist(
                        id='score-filter',
                        options=[{'label': 'Avec score', 'value': 'with_score'}],
                        value=[],
                        inline=True,
                        className="checklist"
                    ),

                    html.Label("Filtrer par Mission Level:"),
                    dcc.Dropdown(
                        id='mission-filter',
                        options=[{"label": level, "value": level} for level in mission_levels],
                        multi=True,
                        placeholder="Sélectionnez un ou plusieurs niveaux de mission",
                        className="dropdown"
                    ),

                    html.Button("Rafraîchir", id='refresh-button', n_clicks=0, className="button"),
                ], className='sidebar'),

                html.Div([
                    html.Label("Nombre de 'completed' par niveau :"),
                    html.Div([
                        dash_table.DataTable(
                            id='completed-counts-table',
                            columns=[
                                {"name": "Mission Level", "id": "Mission Level"},
                                {"name": "Nombre de Completed", "id": "Completed Count"}
                            ],
                            data=[{"Mission Level": level, "Completed Count": count} for level, count in completed_counts.items()],
                            style_table={'height': '300px', 'overflowY': 'auto'},
                            style_cell={'textAlign': 'center', 'padding': '10px'},
                        )
                    ], className="dash-table-box"),  # Table in a box

                    dash_table.DataTable(
                        id='table',
                        columns=[
                            {"name": "Timestamp", "id": "Timestamp"},
                            {"name": "Verb", "id": "Verb"},
                            {"name": "Actor", "id": "Actor"},
                            {"name": "Object", "id": "Object"},
                            {"name": "Score", "id": "Score"},
                            {"name": "Mission Level", "id": "Mission Level"}
                        ],
                        data=df.to_dict('records'),
                        page_size=10,
                        style_table={'height': '400px', 'overflowY': 'auto'},
                        style_cell={'textAlign': 'center', 'padding': '10px'},
                    ),
                ], id="mission-view", style={'display': 'none'}),  # Initially hide mission view

            ], id="mission-view", style={'display': 'none'}),  # Initially hide mission view

        ])
    ], className='dashboard-container'),
], className='dashboard')



# Callback to update the page when toggling the view
@app.callback(
    [Output('table', 'data'),
     Output('score-evolution', 'figure'),
     Output('completed-counts-table', 'data'),
     Output('avg-score-table', 'data'),
     Output('general-view', 'style'),
     Output('mission-view', 'style'),
     Output('mission-filter', 'style')],  # New output for mission-filter visibility
    [Input('refresh-button', 'n_clicks'),
     Input('score-filter', 'value'),
     Input('mission-filter', 'value'),
     Input('toggle-view-button', 'n_clicks')]  # View toggle button input
)
def update_table_and_graph(n_clicks, score_filter, selected_levels, toggle_view_clicks):
    # Force a refresh whenever the toggle view button is clicked
    # When toggle view button is clicked, treat it as a view change to refresh data
    data = fetch_lrs_data()
    df, mission_levels, completed_counts, avg_score_by_level = process_data(data)

    # Handle view toggle
    is_mission_view = toggle_view_clicks % 2 == 1

    # Filter by Score (if "with_score" is selected, only show rows with score)
    if 'with_score' in score_filter:
        df = df[df["Score"].notnull()]  # Keep only rows with a valid score

    # Filter by Mission Level
    if selected_levels:
        df = df[df["Mission Level"].isin(selected_levels)]  # Keep only rows with selected mission levels

    # Filter out rows where 'Mission Level' is None before sorting
    df = df.dropna(subset=["Mission Level"])  # Remove rows where 'Mission Level' is None

    # Group by Mission Level and calculate the maximum score for each level
    mission_grouped = df.groupby("Mission Level")["Score"].max().reset_index()

    # Sort the mission levels by their value
    mission_grouped = mission_grouped.sort_values(by="Mission Level", ascending=True)

    # Generate the bar chart for the final score using Pandas DataFrame
    fig = px.bar(
        mission_grouped,
        x="Mission Level",  # Mission levels as x-axis
        y="Score",  # Maximum score for each mission level
        title="Score final par niveau de mission",
        labels={"Mission Level": "Niveau de Mission", "Score": "Score Final"},
        color="Mission Level",  # Different colors for each mission level
    )

    # Update the visibility based on the view toggle
    general_view_style = {'display': 'block'} if not is_mission_view else {'display': 'none'}
    mission_view_style = {'display': 'none'} if not is_mission_view else {'display': 'block'}

    # Control visibility of the Mission Level filter dropdown
    mission_filter_style = {'display': 'none'} if not is_mission_view else {'display': 'block'}

    return df.to_dict('records'), fig, [{"Mission Level": level, "Completed Count": count} for level, count in completed_counts.items()], [{"Mission Level": level, "Average Score": avg_score} for level, avg_score in avg_score_by_level.items()], general_view_style, mission_view_style, mission_filter_style


if __name__ == '__main__':
    app.run_server(debug=True)
